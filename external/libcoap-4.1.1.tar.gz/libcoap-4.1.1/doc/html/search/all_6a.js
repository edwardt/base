var searchData=
[
  ['join',['join',['../client_8c.html#a70c7909894cffa83654da91616aeca9f',1,'join(coap_context_t *ctx, char *group_name):&#160;client.c'],['../rd_8c.html#a70c7909894cffa83654da91616aeca9f',1,'join(coap_context_t *ctx, char *group_name):&#160;rd.c']]]
];
