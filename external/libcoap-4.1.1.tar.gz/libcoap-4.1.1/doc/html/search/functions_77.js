var searchData=
[
  ['wellknown_5fresponse',['wellknown_response',['../net_8c.html#a014f93810a8dfce9005e4be9df30bfc8',1,'net.c']]],
  ['write_5foption',['write_option',['../uri_8c.html#a92f13607083363523a1315c02db64a86',1,'uri.c']]]
];
