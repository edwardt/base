var searchData=
[
  ['bufsize',['BUFSIZE',['../coap-observer_8c.html#aeca034f67218340ecb2261a22c2f3dcd',1,'BUFSIZE():&#160;coap-observer.c'],['../client_8c.html#aeca034f67218340ecb2261a22c2f3dcd',1,'BUFSIZE():&#160;client.c'],['../etsi__iot__01_8c.html#aeca034f67218340ecb2261a22c2f3dcd',1,'BUFSIZE():&#160;etsi_iot_01.c'],['../rd_8c.html#aeca034f67218340ecb2261a22c2f3dcd',1,'BUFSIZE():&#160;rd.c']]]
];
