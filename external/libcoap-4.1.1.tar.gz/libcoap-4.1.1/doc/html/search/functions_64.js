var searchData=
[
  ['decode_5fsegment',['decode_segment',['../uri_8c.html#a2fec7fe10fc6ed32699cebec122ad9fb',1,'decode_segment(const unsigned char *seg, size_t length, unsigned char *buf):&#160;uri.c'],['../client_8c.html#a2fec7fe10fc6ed32699cebec122ad9fb',1,'decode_segment(const unsigned char *seg, size_t length, unsigned char *buf):&#160;uri.c']]]
];
