var searchData=
[
  ['resource_20observation',['Resource observation',['../group__observe.html',1,'']]]
];
