var searchData=
[
  ['uri_20parsing_20functions',['URI Parsing Functions',['../group__uri__parse.html',1,'']]]
];
