var searchData=
[
  ['_5ftoken_5fdata',['_token_data',['../client_8c.html#a68027829e41d33aa7483576334e56ab8',1,'client.c']]]
];
