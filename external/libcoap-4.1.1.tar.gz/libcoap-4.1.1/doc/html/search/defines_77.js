var searchData=
[
  ['want_5fwkc',['WANT_WKC',['../net_8c.html#af931abc7a93992a2a7925b0915e9fc1f',1,'net.c']]],
  ['warn',['warn',['../debug_8h.html#a8224a361dddd2ad59b411982e5ea746f',1,'debug.h']]]
];
