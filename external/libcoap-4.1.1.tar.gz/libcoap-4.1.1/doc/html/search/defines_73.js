var searchData=
[
  ['stdc_5fheaders',['STDC_HEADERS',['../config_8h.html#a550e5c272cc3cf3814651721167dcd23',1,'config.h']]],
  ['szx_5fto_5fbytes',['SZX_TO_BYTES',['../net_8c.html#a641a52ad5cdf4da5859aa7fc0e5fdf95',1,'net.c']]]
];
