var searchData=
[
  ['set_5fblocksize',['set_blocksize',['../client_8c.html#a3fa80ceabfc89316ee38321bef93351b',1,'client.c']]],
  ['set_5ftimeout',['set_timeout',['../client_8c.html#a207cae0e752016f3bd8e8f6cab4283fd',1,'client.c']]],
  ['strnchr',['strnchr',['../uri_8c.html#a4c7c168a90562e2a5ece60d95a2eace2',1,'uri.c']]]
];
