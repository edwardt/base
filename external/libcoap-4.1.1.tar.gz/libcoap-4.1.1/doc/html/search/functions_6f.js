var searchData=
[
  ['opt_5ffinished',['opt_finished',['../option_8c.html#ad34ae741f83acf83251f2f720f73f58e',1,'option.c']]],
  ['options_5fstart',['options_start',['../option_8c.html#a7c2dec4ec740abfeafc695114602d1cd',1,'options_start(coap_pdu_t *pdu):&#160;option.c'],['../option_8h.html#a7c2dec4ec740abfeafc695114602d1cd',1,'options_start(coap_pdu_t *pdu):&#160;option.c']]],
  ['order_5fopts',['order_opts',['../client_8c.html#a10b4a9a702a002455ee2af4442940265',1,'client.c']]]
];
