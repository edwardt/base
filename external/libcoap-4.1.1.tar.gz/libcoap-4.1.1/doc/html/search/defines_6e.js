var searchData=
[
  ['nn',['Nn',['../encode_8h.html#a4c4631bce2e88ac803ce77b82050c8c5',1,'encode.h']]]
];
