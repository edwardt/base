var searchData=
[
  ['u16',['u16',['../structaddr__t.html#adf5d0adab0dee0cf9c29da6cb3e1da19',1,'addr_t']]],
  ['u8',['u8',['../structaddr__t.html#a11922318781f86b4d7521e65d08045d1',1,'addr_t']]],
  ['uri',['uri',['../structcoap__resource__t.html#aa250947f8ad4cf5e4ebe60ea305c4607',1,'coap_resource_t::uri()'],['../client_8c.html#a7de121932f993685d72a3990ea07480b',1,'uri():&#160;client.c']]]
];
